In these files I manually fix the following issues i nthe BOM:
* C12 should be 4.7nF
* U4 should be 568-12405-1-ND 
